#!/bin/bash
ssh test@one 'export DISPLAY=:0 && firefox /home/test/html/1.html --kiosk'
ssh test@two 'export DISPLAY=:0 && firefox /home/test/html/2.html --kiosk'
ssh test@three 'export DISPLAY=:0 && firefox /home/test/html/3.html --kiosk'
#Per a afegir mes pantalles hi ha que copiar la linea superior i cambiar el domini de, test@three... a test@four..., i tambe hi ha que cambiar el fitxer html, en aquest cas si es 4 alehores es 4.1.html i 4.html
#Per a afegir mes pantalles hi ha que crear mes fitxers html, aleshores executem el script new_html.sh en el client que necesitem, i introduïm el numero corresponent
