#!/bin/bash
read -p "Numero que vols crear: " numero

echo "<html>
<head>
	<link rel='stylesheet' href='a.css'>
</head>
<style>
body {background-color: red;}
</style>
<body>

<center>
<h1>$numero</h1>
</body>
</html>
" > $numero.1.html
echo "<html>
<head>
	<link rel='stylesheet' href='a.css'>
</head>

<body>

<center>
<h1>$numero</h1>
</body>
</html>
" > $numero.html
