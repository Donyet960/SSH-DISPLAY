#!/bin/bash
clear
log=`cat log.txt | sort -r -t: -k2 -n | head -5`
top=1
for line in $log
do
usu=`echo "$line" | cut -d":" -f1`
scr=`echo "$line" | cut -d":" -f2`
if [ $top == 1 ]
then 
echo -e "\e[0;33mTop$top\e[0m \t Usuario: \e[1;36m$usu\e[0m \t Score: \e[1;31m$scr\e[0m"
elif [ $top == 2 ]
then
echo -e "\e[0;30mTop$top\e[0m \t Usuario: \e[1;36m$usu\e[0m \t Score: \e[1;31m$scr\e[0m"
else 
echo -e "Top$top \t Usuario: \e[1;36m$usu\e[0m \t Score: \e[1;31m$scr\e[0m"
fi

top=$((top+1))
done
