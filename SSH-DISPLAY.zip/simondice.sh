#!/bin/bash
xdotool key Ctrl+plus
xdotool key Ctrl+plus
xdotool key Ctrl+plus
xdotool key Ctrl+plus
xdotool key Ctrl+plus
xdotool key Ctrl+plus
xdotool key Ctrl+plus
bash score.sh
echo "Estas prepart?"
read
clear
function bucle {
clear
#Aquest script sols soporta 3 pantalles, per a afegir mes pantalles el que farem sera modificar el random, numa=$((1 + $RANDOM %[numero de clients]))
numa=$((1 + $RANDOM %3 ))
num="$num$numa"
#echo "Numero total: $num"
cnum=`echo -n "$num" | wc -c`
echo "Nivel $cnum"
cnumu=$cnum-1
start=0
for (( c=$start; c<=$cnum; c++ ))
do
#echo "${num:$c:1}"
numre=`echo "${num:$c:1}"`

case $numre in
	1)ssh test@one 'export DISPLAY=:0 && firefox /home/test/html/1.1.html --kiosk && sleep 1 && firefox /home/test/html/1.html --kiosk';;
	2)ssh test@two 'export DISPLAY=:0 && firefox /home/test/html/2.1.html --kiosk && sleep 1 && firefox /home/test/html/2.html --kiosk';;
	3)ssh test@three 'export DISPLAY=:0 && firefox /home/test/html/3.1.html --kiosk && sleep 1 && firefox /home/test/html/3.html --kiosk';;
	#Per a afegir mes pantalles hi ha que copiar la linea superior i cambiar el domini de, test@three... a test@four..., i tambe hi ha que cambiar el fitxer html, en aquest cas si es 4 alehores es 4.1.html i 4.html
	#Per a afegir mes pantalles hi ha que crear mes fitxers html, aleshores executem el script new_html.sh en el client que necesitem, i introduïm el numero corresponent
esac
done

read -p "Numero total?" numusu

if [ $numusu == $num ]
then
echo "Correcte"
bucle
else
echo "Mal"
echo "Era este: $num"
read -p "Nom: " nom
data=`date +%d/%m/%Y`
echo "$nom:$cnum:$data" >> log.txt
fi

}
bucle

